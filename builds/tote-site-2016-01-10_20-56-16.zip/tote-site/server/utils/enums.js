'use strict';

module.exports = {
	permissions: {
		ManageUsers: 1,
		ManageShows: 2,
		ManagePlayers: 3,
		ManageLocations: 4
	}
};
