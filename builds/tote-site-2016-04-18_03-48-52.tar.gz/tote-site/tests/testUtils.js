'use strict';
const errors_1 = require("../server/utils/errors");
const user_1 = require("../server/domain/data/user");
const utils_1 = require("../server/utils/utils");
const utils_2 = require("../server/utils/utils");
let mockery = require('mockery');
let utilsMocked = false, keepCachedMocked = false, mockInstances;
beforeEach(() => {
    mockery.enable({
        warnOnUnregistered: false
    });
    keepCachedMocked = false;
    utilsMocked = false;
    mockInstances = new Map();
});
afterEach(() => {
    mockery.deregisterAll();
    mockery.disable();
    mockInstances = null;
});
function registerMockInstance(mockedType, instance, utilsPath) {
    utilsPath = utilsPath || '../../utils/utils';
    if (!utilsMocked) {
        mockery.registerMock(utilsPath, {
            getInstance: getMockInstance,
            generateRandomString: utils_1.generateRandomString
        });
        utilsMocked = true;
    }
    mockInstances.set(mockedType.name, instance);
    mockery.registerAllowable(utilsPath, true);
    function getMockInstance(type) {
        if (mockInstances.has(type.name)) {
            return mockInstances.get(type.name);
        }
        else {
            return utils_2.getInstance(type);
        }
    }
}
exports.registerMockInstance = registerMockInstance;
function requireUncached(path) {
    const keepCached = [
        '../server/utils/errors'
    ];
    if (!keepCachedMocked) {
        keepCached.forEach(x => mockery.registerMock(x, require(x)));
        keepCachedMocked = true;
    }
    path = '../' + path;
    mockery.registerAllowable(path, true);
    return require(path);
}
exports.requireUncached = requireUncached;
class UserMock extends user_1.User {
    constructor(userId) {
        super();
        this._userId = userId;
        this.hasManagePermission = true;
    }
    get id() {
        return this._userId;
    }
    set id(val) {
        this._userId = val;
    }
    hasPermission() {
        return new Promise((resolve, reject) => this.hasManagePermission ? resolve() : reject(new errors_1.NotAuthorized()));
    }
}
exports.UserMock = UserMock;
//# sourceMappingURL=testUtils.js.map