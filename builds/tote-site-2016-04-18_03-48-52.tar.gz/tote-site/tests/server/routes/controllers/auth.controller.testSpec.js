'use strict';
const auth_provider_1 = require("../../../../server/domain/providers/auth.provider");
const authSession_1 = require("../../../../server/domain/data/authSession");
const errors_1 = require("../../../../server/utils/errors");
const user_1 = require("../../../../server/domain/data/user");
const user_provider_1 = require("../../../../server/domain/providers/user.provider");
const testUtils_1 = require("../../../testUtils");
const testUtils_2 = require("../../../testUtils");
describe('Auth Controller', () => {
    let should = require('should'), sinon = require('sinon'), jwt = require('jsonwebtoken');
    require('should-sinon');
    const username = 'Darth.Vader', password = 'the password of the user', jwtSecret = '12345';
    var AuthController, controller, user, userProviderMock, authProviderMock, data;
    beforeEach(() => {
        userProviderMock = new UserProviderMock();
        testUtils_1.registerMockInstance(user_provider_1.UserProvider, userProviderMock);
        authProviderMock = new AuthProviderMock();
        testUtils_1.registerMockInstance(auth_provider_1.AuthProvider, authProviderMock);
        user = new user_1.User(42);
        user.username = username;
        user.password = password;
        user.markClean();
        userProviderMock.user = user;
        data = {
            body: {
                username: username,
                password: password
            }
        };
        AuthController = testUtils_2.requireUncached('server/routes/controllers/auth.controller').AuthController;
        process.env.TOTE_JWT_SECRET = jwtSecret;
        controller = new AuthController();
    });
    describe('login', () => {
        it('rejects with Forbidden when no user is found', done => {
            userProviderMock.user.username = 'something.else';
            controller.login(data)
                .then(() => done(new Error('Should have thrown error')), err => {
                err.should.be.instanceOf(errors_1.Forbidden);
                done();
            })
                .catch(done);
        });
        it('rejects with Forbidden when password is wrong', done => {
            data.body.password = 'the wrong password';
            controller.login(data)
                .then(() => done(new Error('Should have been rejected')), err => {
                err.should.be.instanceOf(errors_1.Forbidden);
                done();
            })
                .catch(done);
        });
        describe('valid credentials', () => {
            it('creates a new auth session', done => {
                sinon.spy(authProviderMock, 'createAuthSession');
                controller.login(data)
                    .then(() => {
                    authProviderMock.createAuthSession
                        .should.be.calledWith(user.id);
                    done();
                })
                    .catch(done);
            });
            it('eventually returns a valid JWT', done => {
                controller.login(data)
                    .then(result => {
                    should(result).not.be.undefined()
                        .and.not.be.null()
                        .and.have.property('token');
                    let obj = jwt.verify(result.token, jwtSecret);
                    obj.should.have.properties({
                        id: user.id,
                        username: username,
                        sessionKey: authProviderMock.sessionKey
                    });
                    done();
                })
                    .catch(done);
            });
        });
    });
    class UserProviderMock {
        tryFetchUserByUsername(usernameToFind) {
            return new Promise((resolve) => resolve(this.user && this.user.username === usernameToFind
                ? this.user
                : null));
        }
    }
    class AuthProviderMock {
        constructor() {
            this.sessionKey = 'a1b2c3d4';
        }
        createAuthSession() {
            return new authSession_1.AuthSession(user.id, this.sessionKey, new Date(), new Date('2030-10-10'), new Date());
        }
    }
});
//# sourceMappingURL=auth.controller.testSpec.js.map