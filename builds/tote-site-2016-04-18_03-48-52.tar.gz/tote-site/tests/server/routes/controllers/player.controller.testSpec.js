'use strict';
const errors_1 = require("../../../../server/utils/errors");
const errors_2 = require("../../../../server/utils/errors");
const enums_1 = require("../../../../server/utils/enums");
const player_1 = require("../../../../server/domain/data/player");
const player_provider_1 = require("../../../../server/domain/providers/player.provider");
const testUtils_1 = require("../../../testUtils");
const testUtils_2 = require("../../../testUtils");
const testUtils_3 = require("../../../testUtils");
describe('Player Controller', () => {
    let should = require('should'), sinon = require('sinon');
    require('should-sinon');
    const playerId = 21, playerName = 'Joe Namith', playerEmail = 'joe.namith@example.com', playerBio = 'oseph William Namath, nicknamed "Broadway Joe", is a former' +
        ' American football quarterback and actor.', playerImgPath = '/path/to/image.png', playerIsActive = true;
    var PlayerController, controller, player, playerProviderMock, user, data;
    beforeEach(() => {
        player = new player_1.Player(playerId, playerName, playerEmail, playerBio, playerImgPath, playerIsActive);
        user = new testUtils_1.UserMock();
        playerProviderMock = new PlayerProviderMock();
        testUtils_2.registerMockInstance(player_provider_1.PlayerProvider, playerProviderMock);
        data = {
            user: user,
            routeParams: {
                player: playerId
            },
            body: {
                name: player.name,
                email: player.email,
                bio: player.bio,
                imgPath: player.imgPath,
                isActive: player.isActive
            }
        };
        // Ensure we're not using the cached version from other tests
        PlayerController = testUtils_3.requireUncached('server/routes/controllers/player.controller').PlayerController;
        controller = new PlayerController();
    });
    describe('update', () => {
        it('enforces Manage Players permission', done => {
            const requiredPermission = enums_1.Permissions.ManagePlayers;
            user.hasManagePermission = false;
            sinon.spy(user, 'hasPermission');
            controller.update(data)
                .then(() => done(new Error('Should have been rejected')))
                .catch(err => {
                should(err).be.instanceOf(errors_1.NotAuthorized);
                user.hasPermission
                    .should.be.calledWith(requiredPermission);
                done();
            })
                .catch(done);
        });
        it('updates user properties', done => {
            data.body = {
                name: 'Joe Naismith',
                email: 'joe.naismith@example.net',
                bio: 'James Naismith (November 6, 1861 – November 28, 1939) was' +
                    ' a Canadian-American physical educator, physician,' +
                    ' chaplain, sports coach and innovator.',
                imgPath: '/path/to/joe.png',
                isActive: false
            };
            sinon.stub(player, 'save', () => {
                player.name.should.equal(data.body.name);
                player.email.should.equal(data.body.email);
                player.bio.should.equal(data.body.bio);
                player.imgPath.should.equal(data.body.imgPath);
                player.isActive.should.be.false();
            });
            controller.update(data)
                .then(() => {
                player.save.should.be.called();
                done();
            })
                .catch(err => done(err || new Error('Rejected')));
        });
        describe('single properties changed', () => {
            [
                { prop: 'name', value: 'Yoda' },
                { prop: 'email', value: 'yoda@example.org' },
                { prop: 'bio', value: 'A Jedi on a far away planet' },
                { prop: 'imgPath', value: '/path/to/another.jpeg' },
                { prop: 'isActive', value: false }
            ].forEach(x => it('only updates changed property, ' + x.prop, done => {
                data.body = {};
                data.body[x.prop] = x.value;
                sinon.stub(player, 'save', () => {
                    player.name.should.equal(data.body.name || player.name);
                    player.email.should.equal(data.body.email || player.email);
                    player.bio.should.equal(data.body.bio || player.bio);
                    player.imgPath.should.equal(data.body.imgPath || player.imgPath);
                    player.isActive.should.equal(data.body.isActive === undefined);
                });
                controller.update(data)
                    .then(() => {
                    player.save.should.be.called();
                    done();
                })
                    .catch(err => done(err || new Error('Rejected')));
            }));
        });
    });
    describe('create', () => {
        it('creates a new player', done => {
            data.body = {
                name: 'David Bowie',
                email: 'david.bowie@example.io',
                bio: 'Trapped in a tin can',
                imgPath: '/path/to/bowie.space',
                isActive: true
            };
            player = null;
            sinon.stub(playerProviderMock, 'createPlayer', newPlayer => {
                player = newPlayer;
                should(newPlayer).not.be.undefined()
                    .and.not.be.null();
                should(newPlayer.id).be.undefined();
                newPlayer.name.should.equal(data.body.name);
                newPlayer.email.should.equal(data.body.email);
                newPlayer.bio.should.equal(data.body.bio);
                newPlayer.imgPath.should.equal(data.body.imgPath);
                newPlayer.isActive.should.equal(data.body.isActive);
                return newPlayer;
            });
            controller.create(data)
                .then(retPlayer => {
                playerProviderMock.createPlayer
                    .should.be.calledOnce();
                retPlayer.should.be.instanceOf(player_1.Player);
                done();
            })
                .catch(err => done(err || new Error('Error occurred')));
        });
        it('enforces Manage Players permission', done => {
            const requiredPermission = enums_1.Permissions.ManagePlayers;
            user.hasManagePermission = false;
            sinon.spy(user, 'hasPermission');
            controller.create(data)
                .then(() => done(new Error('Should have been rejected')))
                .catch(err => {
                should(err).be.instanceOf(errors_1.NotAuthorized);
                user.hasPermission
                    .should.be.calledWith(requiredPermission);
                done();
            })
                .catch(done);
        });
    });
    class PlayerProviderMock {
        fetchPlayer(id) {
            return new Promise((resolve, reject) => id === player.id
                ? resolve(player)
                : reject(new errors_2.NotFound()));
        }
        createPlayer() { }
    }
});
//# sourceMappingURL=player.controller.testSpec.js.map