'use strict';
const errors_1 = require("../../../../server/utils/errors");
const errors_2 = require("../../../../server/utils/errors");
const enums_1 = require("../../../../server/utils/enums");
const testUtils_1 = require("../../../testUtils");
const user_provider_1 = require("../../../../server/domain/providers/user.provider");
const testUtils_2 = require("../../../testUtils");
const testUtils_3 = require("../../../testUtils");
describe('User Controller', () => {
    let should = require('should'), sinon = require('sinon');
    const userId = 78, username = 'admiral.ackbar', password = '12345', salt = 'abcde', playerId = 85;
    const requiredPermission = enums_1.Permissions.ManageUsers;
    var UserController, controller, User, user, currUser, userProviderMock, data;
    beforeEach(() => {
        currUser = new testUtils_1.UserMock(userId + 1);
        userProviderMock = new UserProviderMock();
        testUtils_2.registerMockInstance(user_provider_1.UserProvider, userProviderMock);
        data = {
            user: currUser,
            routeParams: {
                user: userId
            },
            body: {
                username: username,
                password: password,
                playerId: playerId
            }
        };
        User = testUtils_3.requireUncached('server/domain/data/user').User;
        user = new User(userId, username, password, salt, playerId);
        UserController = testUtils_3.requireUncached('server/routes/controllers/user.controller').UserController;
        controller = new UserController();
    });
    describe('update', () => {
        it('enforces Manage Users permission', done => {
            currUser.hasManagePermission = false;
            sinon.spy(currUser, 'hasPermission');
            controller.update(data)
                .then(() => done(new Error('Should have been rejected')))
                .catch(err => {
                should(err).be.instanceOf(errors_1.NotAuthorized);
                currUser.hasPermission
                    .should.be.calledWith(requiredPermission);
                done();
            })
                .catch(done);
        });
        it('allows updating own password when no permission', done => {
            currUser.id = user.id;
            currUser.hasManagePermission = false;
            data.body.password = 'some new password';
            sinon.spy(user, 'save');
            controller.update(data)
                .then(() => {
                user.password.should.not.equal(password);
                user.save.should.be.called();
                done();
            })
                .catch(err => done(err || new Error('should not have been rejected')));
        });
        it('does not update non-password when no permission', done => {
            currUser.id = user.id;
            currUser.hasManagePermission = false;
            data.body = {
                password: 'some new password',
                username: 'userame.not.updated',
                playerId: 34
            };
            sinon.spy(user, 'save');
            controller.update(data)
                .then(() => {
                user.password.should.not.equal(password);
                user.username.should.equal(username);
                user.playerId.should.equal(playerId);
                user.save.should.be.called();
                done();
            })
                .catch(err => done(err || new Error('should not have been rejected')));
        });
        it('updates all fields of own user when has permission', done => {
            currUser.id = user.id;
            updateCheck(done);
        });
        it('updates fields of other user when has permission', updateCheck);
        function updateCheck(done) {
            currUser.hasManagePermission = true;
            data.body = {
                password: 'some new password',
                username: 'userame.not.updated',
                playerId: 34
            };
            sinon.spy(user, 'save');
            controller.update(data)
                .then(() => {
                user.password.should.not.equal(password);
                user.username.should.equal(data.body.username);
                user.playerId.should.equal(data.body.playerId);
                user.save.should.be.called();
                done();
            })
                .catch(err => done(err || new Error('should not have been rejected')));
        }
    });
    class UserProviderMock {
        fetchUser(id) {
            return new Promise((resolve, reject) => id === userId ? resolve(user) : reject(new errors_2.NotFound()));
        }
        updateUser() {
            return new Promise(resolve => resolve());
        }
    }
});
//# sourceMappingURL=user.controller.testSpec.js.map