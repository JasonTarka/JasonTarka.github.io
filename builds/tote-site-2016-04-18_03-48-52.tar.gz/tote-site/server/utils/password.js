'use strict';
let scrypt = require('scrypt');
// Maximum time to spend hashing (in seconds)
const MAX_TIME = process.env.TOTE_PASSWORD_TIME
    ? parseFloat(process.env.TOTE_PASSWORD_TIME)
    : 0.9;
function hashPassword(password, salt) {
    password = saltPassword(password, salt);
    let params = scrypt.paramsSync(MAX_TIME);
    let hashBuffer = scrypt.kdfSync(password, params);
    let hash = hashBuffer.toString('base64');
    return hash;
}
exports.hashPassword = hashPassword;
function verifyPassword(hash, password, salt) {
    if (typeof hash === 'string') {
        hash = new Buffer(hash, 'base64');
    }
    else if (!(hash instanceof Buffer)) {
        throw new Error('hash must be a Buffer of base64-encoded string');
    }
    password = saltPassword(password, salt);
    return scrypt.verifyKdf(hash, password);
}
exports.verifyPassword = verifyPassword;
function saltPassword(password, salt) {
    return salt + ' ' + password + salt;
}
//# sourceMappingURL=password.js.map