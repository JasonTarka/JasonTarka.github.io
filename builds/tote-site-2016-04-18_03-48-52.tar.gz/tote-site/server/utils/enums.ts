'use strict';

export enum Permissions {
	ManageUsers = 1,
	ManageShows = 2,
	ManagePlayers = 3,
	ManageLocations = 4
}
