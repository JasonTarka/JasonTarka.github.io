'use strict';
const errors_1 = require("./errors");
const EMAIL_REGEX = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
class InputConverter {
    static toEmail(input, name) {
        if (typeof input !== 'string'
            || !input.match(EMAIL_REGEX)) {
            throw new errors_1.InvalidParameter('"' + name + '" is not a valid email');
        }
        return input;
    }
    static toId(input, name) {
        let error = '"' + name + '" is not a valid ID';
        if (!isFinite(input)
            || (typeof input === 'string' && input.indexOf('e') >= 0)) {
            throw new errors_1.InvalidParameter(error);
        }
        let number = parseFloat(input);
        if (number % 1 !== 0
            || number < 0) {
            throw new errors_1.InvalidParameter(error);
        }
        return number;
    }
}
exports.InputConverter = InputConverter;
//# sourceMappingURL=inputConverter.js.map