'use strict';
(function (Permissions) {
    Permissions[Permissions["ManageUsers"] = 1] = "ManageUsers";
    Permissions[Permissions["ManageShows"] = 2] = "ManageShows";
    Permissions[Permissions["ManagePlayers"] = 3] = "ManagePlayers";
    Permissions[Permissions["ManageLocations"] = 4] = "ManageLocations";
})(exports.Permissions || (exports.Permissions = {}));
var Permissions = exports.Permissions;
//# sourceMappingURL=enums.js.map