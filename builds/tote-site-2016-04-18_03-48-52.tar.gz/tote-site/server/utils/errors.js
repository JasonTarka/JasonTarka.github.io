'use strict';
class HttpError extends Error {
    constructor(message) {
        super(message);
    }
}
exports.HttpError = HttpError;
/***** 4xx *****/
class BadRequest extends HttpError {
    constructor(message) {
        super(message || 'Bad Request Parameters');
        this.name = 'Bad Request';
        this.status = 400;
    }
}
exports.BadRequest = BadRequest;
class InvalidParameter extends BadRequest {
    constructor(message) {
        super(message || 'Invalid Parameter');
    }
}
exports.InvalidParameter = InvalidParameter;
class NotAuthorized extends HttpError {
    constructor(message) {
        super(message || 'Not Authorized');
        this.name = 'Not Authorized';
        this.status = 401;
    }
}
exports.NotAuthorized = NotAuthorized;
class Forbidden extends HttpError {
    constructor(message) {
        super(message || 'Forbidden');
        this.name = 'Forbidden';
        this.status = 403;
    }
}
exports.Forbidden = Forbidden;
class NotFound extends HttpError {
    constructor(message) {
        super(message || 'Not Found');
        this.name = 'Not Found';
        this.status = 404;
    }
}
exports.NotFound = NotFound;
/***** 5xx *****/
class InternalServerError extends HttpError {
    constructor(message) {
        super(message);
        this.name = 'Internal Server Error';
        this.status = 500;
    }
}
exports.InternalServerError = InternalServerError;
/**
 * For when a function has not been implemented, or correctly overridden.
 * Should never reach the user, but results in a generic 500 error.
 */
class FunctionNotImplemented extends InternalServerError {
    constructor(message) {
        super(message || 'Function not implemented');
    }
}
exports.FunctionNotImplemented = FunctionNotImplemented;
/**
 * For when a feature has not been implemented in the API.
 * Specifically a 501 error.
 */
class FeatureNotImplemented extends InternalServerError {
    constructor(message) {
        super(message || 'Not Implemented');
        this.status = 501;
    }
}
exports.FeatureNotImplemented = FeatureNotImplemented;
//# sourceMappingURL=errors.js.map