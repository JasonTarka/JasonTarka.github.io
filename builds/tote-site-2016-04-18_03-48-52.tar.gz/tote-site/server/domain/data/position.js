'use strict';
const dataObject_1 = require("./dataObject");
const errors_1 = require("../../utils/errors");
class Position extends dataObject_1.DataObject {
    constructor(id, name, sortOrder) {
        super({
            id: id,
            name: name,
            sortOrder: sortOrder
        });
    }
    get data() {
        let data = this._getFieldVals();
        delete data.sortOrder;
        return data;
    }
    /***** id *****/
    get id() {
        return this._getFieldVal('id');
    }
    /***** name *****/
    get name() {
        return this._getFieldVal('name');
    }
    set name(val) {
        if (!val) {
            throw new errors_1.InvalidParameter('"name" cannot be empty');
        }
    }
    /***** Sort Order *****/
    get sortOrder() {
        return this._getFieldVal('sortOrder');
    }
    set sortOrder(val) {
        this._setFieldVal('sortOrder', val);
    }
}
exports.Position = Position;
//# sourceMappingURL=position.js.map