'use strict';
const dataObject_1 = require("./dataObject");
const inputConverter_1 = require("../../utils/inputConverter");
const player_provider_1 = require("../providers/player.provider");
const position_provider_1 = require("../providers/position.provider");
const utils_1 = require("../../utils/utils");
class ShowPosition extends dataObject_1.DataObject {
    constructor(showId, positionId, playerId) {
        super({
            showId: showId,
            positionId: positionId,
            playerId: playerId
        });
    }
    get data() {
        let playerProvider = utils_1.getInstance(player_provider_1.PlayerProvider), positionProvider = utils_1.getInstance(position_provider_1.PositionProvider);
        let data = {
            player: playerProvider.fetchPlayer(this.playerId),
            position: positionProvider.fetchPosition(this.positionId)
        };
        return data;
    }
    /***** Show ID *****/
    get showId() {
        return this._getFieldVal('showId');
    }
    /***** Position ID *****/
    get positionId() {
        return this._getFieldVal('positionId');
    }
    /***** Player ID *****/
    get playerId() {
        return this._getFieldVal('playerId');
    }
    set playerId(val) {
        val = inputConverter_1.InputConverter.toId(val, 'playerId');
        this._setFieldVal('playerId', val);
    }
}
exports.ShowPosition = ShowPosition;
//# sourceMappingURL=showPosition.js.map