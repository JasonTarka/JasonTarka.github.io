'use strict';
const dataObject_1 = require("./dataObject");
const inputConverter_1 = require("../../utils/inputConverter");
class Location extends dataObject_1.DataObject {
    constructor(id, name, isDefault) {
        super({
            id: id,
            name: name,
            isDefault: isDefault
        });
    }
    /***** Show ID *****/
    get showId() {
        return this._getFieldVal('showId');
    }
    /***** Position ID *****/
    get positionId() {
        return this._getFieldVal('positionId');
    }
    /***** Player ID *****/
    get playerId() {
        return this._getFieldVal('playerId');
    }
    set playerId(val) {
        val = inputConverter_1.InputConverter.toId(val, 'playerId');
        this._setFieldVal('playerId', val);
    }
}
exports.Location = Location;
//# sourceMappingURL=location.js.map