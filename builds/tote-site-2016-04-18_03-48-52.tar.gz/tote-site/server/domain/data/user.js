'use strict';
const dataObject_1 = require("./dataObject");
const inputConverter_1 = require("../../utils/inputConverter");
const errors_1 = require("../../utils/errors");
const errors_2 = require("../../utils/errors");
const user_provider_1 = require("../providers/user.provider");
const utils_1 = require("../../utils/utils");
const utils_2 = require("../../utils/utils");
const password_1 = require("../../utils/password");
exports.MIN_PASSWORD_LENGTH = 8, exports.MAX_SALT_LENGTH = 20;
let _permissions = new WeakMap();
class User extends dataObject_1.DataObject {
    constructor(id, username, password, salt, playerId) {
        super({
            id: id,
            username: username,
            password: password,
            salt: salt,
            playerId: playerId
        });
    }
    get data() {
        let data = this._getFieldVals();
        delete data.password;
        delete data.salt;
        return data;
    }
    get identifierFields() {
        return ['id'];
    }
    // ----- id -----
    get id() {
        return this._getFieldVal('id');
    }
    // ----- username -----
    get username() {
        return this._getFieldVal('username');
    }
    set username(val) {
        if (!val) {
            throw new errors_1.InvalidParameter('"username" must not be empty');
        }
        if (typeof val !== 'string'
            || !val.match(/^[a-zA-Z0-9_.-]+$/)) {
            throw new errors_1.InvalidParameter('"username" is not valid');
        }
        this._setFieldVal('username', val.toString());
    }
    // ----- password -----
    get password() {
        return this._getFieldVal('password');
    }
    set password(val) {
        if (!val
            || typeof val !== 'string') {
            throw new errors_1.InvalidParameter('"password" must not be empty');
        }
        else if (val.length < exports.MIN_PASSWORD_LENGTH) {
            throw new errors_1.InvalidParameter('"password" must have at least ' + exports.MIN_PASSWORD_LENGTH + ' characters');
        }
        let salt = utils_1.generateRandomString(exports.MAX_SALT_LENGTH), password = password_1.hashPassword(val, salt);
        this._setFieldVal('salt', salt);
        this._setFieldVal('password', password);
    }
    // ----- salt -----
    get salt() {
        return this._getFieldVal('salt');
    }
    // ----- player ID -----
    get playerId() {
        return this._getFieldVal('playerId');
    }
    set playerId(val) {
        val = inputConverter_1.InputConverter.toId(val, 'playerId');
        this._setFieldVal('playerId', val);
    }
    save() {
        if (!this.id) {
            throw new Error('Cannot create user');
        }
        let provider = utils_2.getInstance(user_provider_1.UserProvider);
        return provider.updateUser(this)
            .then(() => this);
    }
    /**
     * Checks if the user has a given permission or not.
     * Resolves the promise if the permission is available, and rejects it
     * otherwise.
     *
     * @param permissionId
     */
    hasPermission(permissionId) {
        return new Promise((resolve, reject) => {
            if (!_permissions.get(this)) {
                let provider = utils_2.getInstance(user_provider_1.UserProvider);
                provider.fetchPermissionsForUser(this.id)
                    .then(perms => {
                    _permissions.set(this, new Set(perms.map(x => x.id)));
                    if (_permissions.get(this).has(permissionId)) {
                        resolve();
                    }
                    else {
                        reject(new errors_2.NotAuthorized());
                    }
                })
                    .catch(reject);
            }
            else if (_permissions.get(this).has(permissionId)) {
                resolve();
            }
            else {
                reject(new errors_2.NotAuthorized());
            }
        });
    }
}
exports.User = User;
//# sourceMappingURL=user.js.map