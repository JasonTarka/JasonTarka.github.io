'use strict';
const dataObject_1 = require('./dataObject');
class Permission extends dataObject_1.DataObject {
    constructor(id, name) {
        super({
            id: id,
            name: name
        });
    }
    get data() {
        return {
            id: this.id,
            name: this.name
        };
    }
    get id() {
        return this._getFieldVal('id');
    }
    get name() {
        return this._getFieldVal('name');
    }
}
exports.Permission = Permission;
//# sourceMappingURL=permission.js.map