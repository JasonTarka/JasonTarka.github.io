'use strict';
const errors_1 = require("../../utils/errors");
const utils_1 = require("../../utils/utils");
let _data = new WeakMap();
class DataObject {
    constructor(data) {
        this.dirtyFields = new Set();
        _data.set(this, data);
    }
    markClean() {
        this.dirtyFields = new Set();
    }
    get isDirty() {
        return !!this.dirtyFields.size;
    }
    /***** Methods/Properties to be overridden *****/
    get data() {
        return this._getFieldVals();
    }
    /**
     * An array of fields that are used as identifiers for this object.
     * eg: primary keys in the database
     */
    get identifierFields() {
        throw new errors_1.FunctionNotImplemented();
    }
    /**
     * An array containing all fields this object contains.
     */
    get fieldNames() {
        return Object.keys(_data.get(this));
    }
    /**
     * Update field values in this object using the matching fields from a
     * hash-object.
     */
    updateFieldVals(data) {
        let idFields = this.identifierFields;
        this.fieldNames
            .filter(x => data.hasOwnProperty(x)
            && idFields.indexOf(x) < 0)
            .forEach(field => this[field] = data[field]);
    }
    /***** Private/Protected methods *****/
    _markDirty(field) {
        if (!this.dirtyFields.has(field)) {
            this.dirtyFields.add(field);
        }
    }
    _getFieldVal(field) {
        return _data.get(this)[field];
    }
    _getFieldVals() {
        return utils_1.clone(_data.get(this));
    }
    _setFieldVal(field, value) {
        let data = _data.get(this);
        if (data[field] === value) {
            return;
        }
        data[field] = value;
        this._markDirty(field);
    }
}
exports.DataObject = DataObject;
//# sourceMappingURL=dataObject.js.map