'use strict';
const auth_provider_1 = require("../providers/auth.provider");
const utils_1 = require("../../utils/utils");
class AuthSession {
    constructor(userId, sessionKey, dateCreated, validUntil, lastUsed) {
        this.userId = userId;
        this.sessionKey = sessionKey;
        this.dateCreated = new Date(dateCreated);
        this.validUntil = new Date(validUntil);
        this.lastUsed = new Date(lastUsed);
    }
    get isValid() {
        let now = new Date();
        return now < this.validUntil;
    }
    markUsed() {
        let provider = utils_1.getInstance(auth_provider_1.AuthProvider);
        provider.markAuthSessionUsed(this.userId, this.sessionKey);
    }
}
exports.AuthSession = AuthSession;
//# sourceMappingURL=authSession.js.map