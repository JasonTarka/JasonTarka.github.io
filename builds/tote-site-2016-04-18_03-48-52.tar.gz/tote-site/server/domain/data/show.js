'use strict';
const dataObject_1 = require("./dataObject");
const errors_1 = require("../../utils/errors");
const showPosition_1 = require("./showPosition");
class Show extends dataObject_1.DataObject {
    constructor(id, locationId, date, tagLine, showPositions) {
        super({
            id: id,
            locationId: locationId,
            date: date,
            tagLine: tagLine,
            showPositions: showPositions
        });
    }
    /***** Show ID *****/
    get id() {
        return this._getFieldVal('id');
    }
    /***** Location ID *****/
    get locationId() {
        return this._getFieldVal('locationId');
    }
    set locationId(val) {
        this._setFieldVal('locationId', val);
    }
    /***** Date *****/
    get date() {
        return this._getFieldVal('date');
    }
    set date(val) {
        if (!val) {
            throw new errors_1.InvalidParameter('"date" cannot be null');
        }
        let tempVal = val;
        if (typeof tempVal !== 'object') {
            val = new Date(tempVal);
        }
        if (isNaN(val.getTime())) {
            throw new errors_1.InvalidParameter('"date" must be a valid date');
        }
        this._setFieldVal('playerId', val);
    }
    /***** Tag Line *****/
    get tagLine() {
        return this._getFieldVal('tagLine');
    }
    set name(val) {
        this._setFieldVal('tagLine', val);
    }
    /****** Show Positions *****/
    get showPositions() {
        return this._getFieldVal('showPositions');
    }
    set showPositions(val) {
        if (!(val instanceof Array)
            || !val.every(x => x instanceof showPosition_1.ShowPosition)) {
            throw new errors_1.InvalidParameter('"showPositions" must be an array of Show Positions');
        }
        this._setFieldVal('showPositions', val);
    }
}
exports.Show = Show;
//# sourceMappingURL=show.js.map