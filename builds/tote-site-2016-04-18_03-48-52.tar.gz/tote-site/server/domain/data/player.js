'use strict';
const dataObject_1 = require('./dataObject');
const inputConverter_1 = require("../../utils/inputConverter");
const errors_1 = require("../../utils/errors");
const player_provider_1 = require("../providers/player.provider");
const utils_1 = require("../../utils/utils");
class Player extends dataObject_1.DataObject {
    constructor(id, name, email, bio, imgPath, isActive) {
        super({
            id: id,
            name: name,
            email: email,
            bio: bio,
            imgPath: imgPath,
            isActive: isActive
        });
    }
    get data() {
        return this._getFieldVals();
    }
    get identifierFields() {
        return ['id'];
    }
    // ----- id -----
    get id() {
        return this._getFieldVal('id');
    }
    // ----- name -----
    get name() {
        return this._getFieldVal('name');
    }
    set name(val) {
        if (!val) {
            throw new errors_1.InvalidParameter('"name" must not be empty');
        }
        this._setFieldVal('name', val.toString());
    }
    // ----- email -----
    get email() {
        return this._getFieldVal('email');
    }
    set email(val) {
        val = inputConverter_1.InputConverter.toEmail(val, 'email');
        this._setFieldVal('email', val);
    }
    // ----- bio -----
    get bio() {
        return this._getFieldVal('bio');
    }
    set bio(val) {
        this._setFieldVal('bio', val.toString());
    }
    // ----- imgPath -----
    get imgPath() {
        return this._getFieldVal('imgPath');
    }
    set imgPath(val) {
        val = val ? val.toString() : null;
        this._setFieldVal('imgPath', val);
    }
    // ----- imgPath -----
    get isActive() {
        return this._getFieldVal('isActive');
    }
    set isActive(value) {
        let val = value; // TypeScript hack to allow for input validation
        if (val === false || val === 0 || val === '0' || val === 'false') {
            val = false;
        }
        else if (val === true || val === 1 || val === '1' || val === 'true') {
            val = true;
        }
        else {
            throw new errors_1.InvalidParameter('isActive must be a boolean');
        }
        this._setFieldVal('isActive', val);
    }
    save() {
        if (!this.id) {
            throw new Error('Cannot create player');
        }
        let provider = utils_1.getInstance(player_provider_1.PlayerProvider);
        return provider.updatePlayer(this)
            .then(() => this);
    }
}
exports.Player = Player;
//# sourceMappingURL=player.js.map