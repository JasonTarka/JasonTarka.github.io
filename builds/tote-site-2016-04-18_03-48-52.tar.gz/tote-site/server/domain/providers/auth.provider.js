'use strict';
const authSession_1 = require("../data/authSession");
const database_1 = require("./database");
const errors_1 = require("../../utils/errors");
const utils_1 = require("../../utils/utils");
exports.SESSION_KEY_LENGTH = 20;
class AuthProvider {
    constructor() {
        this._sessionLength = process.env.TOTE_SESSION_LENGTH_MINUTES
            ? process.env.TOTE_SESSION_LENGTH_MINUTES
            : 300;
    }
    get _db() {
        return database_1.Database.instance;
    }
    get _newValidUntilDate() {
        let date = new Date(), millis = this._sessionLength * 60 * 1000;
        date.setTime(date.getTime() + millis);
        return date;
    }
    createAuthSession(userId) {
        let sql = 'INSERT INTO user_auth_sessions' +
            '(userId, sessionKey, validUntilDate, lastUsedDate)' +
            ' VALUES(?,?,?,?)', sessionKey = utils_1.generateRandomString(exports.SESSION_KEY_LENGTH), params = [
            userId,
            sessionKey,
            this._newValidUntilDate,
            new Date()
        ];
        return this._db.executeInsert(sql, params)
            .then(() => this.fetchAuthSession(userId, sessionKey));
    }
    fetchAuthSession(userId, sessionKey) {
        let sql = 'SELECT userId, sessionKey, dateCreated, ' +
            'validUntilDate, lastUsedDate' +
            ' FROM user_auth_sessions' +
            ' WHERE userId = ?' +
            '   AND sessionKey = ?', params = [userId, sessionKey];
        return this._db.executeQuery(sql, params)
            .then((rows) => {
            if (!rows || !rows.length) {
                throw new errors_1.Forbidden();
            }
            return createAuthSession(rows[0]);
        });
    }
    markAuthSessionUsed(userId, sessionKey) {
        let sql = 'UPDATE user_auth_sessions' +
            ' SET validUntilDate = ?,' +
            ' lastUsedDate = NOW()' +
            ' WHERE userId = ?' +
            ' AND sessionKey = ?', params = [
            this._newValidUntilDate,
            userId,
            sessionKey
        ];
        return this._db.executeNonQuery(sql, params);
    }
}
exports.AuthProvider = AuthProvider;
function createAuthSession(row) {
    let session = new authSession_1.AuthSession(row.userId, row.sessionKey, row.dateCreated, row.validUntilDate, row.lastUsedDate);
    return session;
}
//# sourceMappingURL=auth.provider.js.map