'use strict';
const database_1 = require("./database");
const errors_1 = require("../../utils/errors");
const position_1 = require("../data/position");
class PositionProvider {
    get _db() {
        return database_1.Database.instance;
    }
    fetchPositions() {
        let sql = 'SELECT * FROM positions ORDER BY sortOrder';
        return new Promise((resolve, reject) => {
            this._db.executeQuery(sql)
                .then(rows => resolve(rows.map(createPosition)))
                .catch(reject);
        });
    }
    fetchPosition(positionId) {
        let sql = 'SELECT * FROM positions WHERE id = ?';
        return new Promise((resolve, reject) => {
            this._db.executeQuery(sql, [positionId])
                .then(positions => {
                if (!positions || positions.length === 0) {
                    return reject(new errors_1.NotFound('Position not found'));
                }
                resolve(createPosition(positions[0]));
            })
                .catch(reject);
        });
    }
}
exports.PositionProvider = PositionProvider;
function createPosition(row) {
    let position = new position_1.Position(row.id, row.name, row.sortOrder);
    return position;
}
//# sourceMappingURL=position.provider.js.map