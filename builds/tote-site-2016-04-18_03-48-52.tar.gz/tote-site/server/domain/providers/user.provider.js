'use strict';
const database_1 = require("./database");
const errors_1 = require("../../utils/errors");
const user_1 = require("../data/user");
const permission_1 = require("../data/permission");
class UserProvider {
    get _db() {
        return database_1.Database.instance;
    }
    createUser(user) {
        let sql = 'INSERT INTO users(username, password, salt, playerId) ' +
            'VALUES(?, ?, ?, ?)', values = [user.username, user.password, user.salt, user.playerId];
        return this._db.executeInsert(sql, values)
            .then(newId => this.fetchUser(newId));
    }
    fetchUsers() {
        let sql = 'SELECT * FROM users WHERE deleted = 0';
        return new Promise((resolve, reject) => {
            this._db.executeQuery(sql)
                .then(rows => resolve(rows.map(createUser)))
                .catch(reject);
        });
    }
    fetchUser(userId) {
        let sql = 'SELECT * FROM users WHERE id = ? AND deleted = 0';
        return new Promise((resolve, reject) => {
            this._db.executeQuery(sql, [userId])
                .then(users => {
                if (!users || users.length === 0) {
                    return reject(new errors_1.NotFound('User not found'));
                }
                resolve(createUser(users[0]));
            })
                .catch(reject);
        });
    }
    /**
     * Try to fetch the user matching the given username.
     * If no user is found then the promise will be resolved with {null}.
     */
    tryFetchUserByUsername(username) {
        let sql = 'SELECT * FROM users WHERE username = ? AND deleted = 0';
        return new Promise((resolve, reject) => {
            this._db.executeQuery(sql, [username])
                .then(users => {
                if (!users || users.length === 0) {
                    return resolve(null);
                }
                resolve(createUser(users[0]));
            })
                .catch(reject);
        });
    }
    fetchPermissionsForUser(userId) {
        let sql = 'SELECT permissionId FROM user_permissions WHERE userId = ?', params = [userId];
        return this._db.executeQuery(sql, params)
            .then(rows => rows.map(createPermission));
    }
    updateUser(user) {
        return this._db.updateDataObject(user, 'users');
    }
}
exports.UserProvider = UserProvider;
function createUser(row) {
    let user = new user_1.User(row.id, row.username, row.password, row.salt, row.playerId);
    return user;
}
function createPermission(row) {
    let permission = new permission_1.Permission(row.id || row.permissionId, row.name);
    return permission;
}
//# sourceMappingURL=user.provider.js.map