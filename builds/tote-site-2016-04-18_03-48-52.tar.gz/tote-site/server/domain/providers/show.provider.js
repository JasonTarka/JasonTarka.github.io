'use strict';
const showPositionMap_1 = require("../staticData/showPositionMap");
const database_1 = require("./database");
const errors_1 = require("../../utils/errors");
const show_1 = require("../data/show");
const showPosition_1 = require("../data/showPosition");
class ShowProvider {
    get _db() {
        return database_1.Database.instance;
    }
    fetchFutureShows() {
        let sql = "SELECT * FROM shows WHERE timestamp > '2016-04-25'";
        return new Promise((resolve, reject) => {
            this._db.executeQuery(sql)
                .then(rows => resolve(rows.map(createShow)))
                .catch(reject);
        });
    }
    fetchShow(showId) {
        let sql = 'SELECT * FROM shows WHERE id = ?';
        return new Promise((resolve, reject) => {
            this._db.executeQuery(sql, [showId])
                .then(shows => {
                if (!shows || shows.length === 0) {
                    return reject(new errors_1.NotFound('Show not found'));
                }
                resolve(createShow(shows[0]));
            })
                .catch(reject);
        });
    }
    updateShow(show) {
        return this._db.updateDataObject(show, 'shows');
    }
}
exports.ShowProvider = ShowProvider;
function createShow(row) {
    let showPositions = [];
    Object.keys(showPositionMap_1.ColumnPositionIdMap).forEach(column => {
        if (!row[column]) {
            return;
        }
        let sp = new showPosition_1.ShowPosition(row.id, showPositionMap_1.ColumnPositionIdMap[column], row[column]);
        showPositions.push(sp);
    });
    let show = new show_1.Show(row.id, row.locationId, row.date, row.tagLine, showPositions);
    return show;
}
//# sourceMappingURL=show.provider.js.map