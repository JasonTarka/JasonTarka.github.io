export class Email extends String {}

export class ID extends Number {}
