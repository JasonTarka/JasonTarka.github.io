'use strict';
const show_provider_1 = require("../../domain/providers/show.provider");
const route_1 = require("../data/route");
const routingInfo_1 = require("../data/routingInfo");
const utils_1 = require("../../utils/utils");
class ShowController {
    get _provider() {
        return utils_1.getInstance(show_provider_1.ShowProvider);
    }
    list() {
        return this._provider.fetchFutureShows();
    }
    view(data) {
        let showId = data.routeParams.show;
        return this._provider.fetchShow(showId);
    }
    get routing() {
        return new routingInfo_1.RoutingInfo('/shows', [
            new route_1.Route('/', this.list),
            new route_1.Route('/:show', this.view)
        ]);
    }
}
exports.ShowController = ShowController;
//# sourceMappingURL=show.controller.js.map