import {RoutingInfo} from "../data/routingInfo";

export interface IController {
	routing:RoutingInfo;
}
