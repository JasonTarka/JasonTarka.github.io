'use strict';
const auth_provider_1 = require("../../domain/providers/auth.provider");
const errors_1 = require("../../utils/errors");
const errors_2 = require("../../utils/errors");
const route_1 = require("../data/route");
const routingInfo_1 = require("../data/routingInfo");
const user_provider_1 = require("../../domain/providers/user.provider");
const password_1 = require("../../utils/password");
const utils_1 = require("../../utils/utils");
let jwt = require('jsonwebtoken');
class AuthController {
    constructor() {
        this.jwtSecret = process.env.TOTE_JWT_SECRET;
    }
    get _provider() {
        return utils_1.getInstance(user_provider_1.UserProvider);
    }
    get _authProvider() {
        return utils_1.getInstance(auth_provider_1.AuthProvider);
    }
    login(data) {
        let body = data.body;
        if (!body || !body.username || !body.password) {
            throw new errors_1.BadRequest('Must include a username and password');
        }
        let errorMessage = 'Invalid username or password';
        return this._provider.tryFetchUserByUsername(body.username)
            .then(user => {
            if (user == null) {
                throw new errors_2.Forbidden(errorMessage);
            }
            return password_1.verifyPassword(user.password, body.password, user.salt)
                .then(isValid => {
                if (!isValid) {
                    throw new errors_2.Forbidden(errorMessage);
                }
            })
                .then(() => this._authProvider.createAuthSession(user.id))
                .then(authSession => {
                let token = jwt.sign({
                    id: user.id,
                    username: user.username,
                    sessionKey: authSession.sessionKey
                }, this.jwtSecret);
                return {
                    token: token
                };
            });
        });
    }
    get routing() {
        return new routingInfo_1.RoutingInfo('/auth', [
            new route_1.Route('/login', this.login, 'POST')
        ]);
    }
}
exports.AuthController = AuthController;
//# sourceMappingURL=auth.controller.js.map