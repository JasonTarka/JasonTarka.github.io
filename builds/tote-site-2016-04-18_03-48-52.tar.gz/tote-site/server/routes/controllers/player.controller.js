'use strict';
const enums_1 = require("../../utils/enums");
const player_1 = require("../../domain/data/player");
const player_provider_1 = require("../../domain/providers/player.provider");
const route_1 = require("../data/route");
const routingInfo_1 = require("../data/routingInfo");
const utils_1 = require("../../utils/utils");
class PlayerController {
    get _provider() {
        return utils_1.getInstance(player_provider_1.PlayerProvider);
    }
    list() {
        return this._provider.fetchPlayers();
    }
    view(data) {
        let playerId = data.routeParams.player;
        return this._provider.fetchPlayer(playerId);
    }
    create(data) {
        let body = data.body;
        return data.user.hasPermission(enums_1.Permissions.ManagePlayers)
            .then(() => {
            let player = new player_1.Player();
            player.updateFieldVals(body);
            return this._provider.createPlayer(player);
        });
    }
    update(data) {
        let playerId = data.routeParams.player, body = data.body;
        return data.user.hasPermission(enums_1.Permissions.ManagePlayers)
            .then(() => this._provider.fetchPlayer(playerId))
            .then(player => {
            player.updateFieldVals(body);
            return player.save();
        });
    }
    get routing() {
        return new routingInfo_1.RoutingInfo('/players', [
            new route_1.Route('/', this.list),
            new route_1.Route('/', this.create, 'POST', true),
            new route_1.Route('/:player', this.view),
            new route_1.Route('/:player', this.update, 'PATCH', true)
        ]);
    }
}
exports.PlayerController = PlayerController;
//# sourceMappingURL=player.controller.js.map