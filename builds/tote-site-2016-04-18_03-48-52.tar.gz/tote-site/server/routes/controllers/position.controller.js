'use strict';
const position_provider_1 = require("../../domain/providers/position.provider");
const route_1 = require("../data/route");
const routingInfo_1 = require("../data/routingInfo");
const utils_1 = require("../../utils/utils");
class PositionController {
    get _provider() {
        return utils_1.getInstance(position_provider_1.PositionProvider);
    }
    list() {
        return this._provider.fetchPositions();
    }
    view(data) {
        let positionId = data.routeParams.position;
        return this._provider.fetchPosition(positionId);
    }
    get routing() {
        return new routingInfo_1.RoutingInfo('/positions', [
            new route_1.Route('/', this.list, 'GET', true),
            new route_1.Route('/:position', this.view, 'GET', true)
        ]);
    }
}
exports.PositionController = PositionController;
//# sourceMappingURL=position.controller.js.map