'use strict';
const errors_1 = require("../../utils/errors");
const enums_1 = require("../../utils/enums");
const routingInfo_1 = require("../data/routingInfo");
const route_1 = require("../data/route");
const user_1 = require("../../domain/data/user");
const user_provider_1 = require("../../domain/providers/user.provider");
const utils_1 = require("../../utils/utils");
class UserController {
    get _provider() {
        return utils_1.getInstance(user_provider_1.UserProvider);
    }
    list() {
        return this._provider.fetchUsers();
    }
    view(data) {
        let userId = data.routeParams.user;
        return this._provider.fetchUser(userId);
    }
    create(data) {
        return data.user.hasPermission(enums_1.Permissions.ManagePlayers)
            .then(() => {
            let body = data.body;
            let user = new user_1.User();
            user.username = body.username;
            user.password = body.password;
            user.playerId = body.playerId;
            return this._provider.createUser(user);
        });
    }
    update(data) {
        let body = data.body, currUser = data.user, userId = data.routeParams.user;
        return new Promise((resolve, reject) => {
            currUser.hasPermission(enums_1.Permissions.ManageUsers)
                .then(() => this._provider.fetchUser(userId))
                .then(user => {
                user.updateFieldVals(body);
                return user.save();
            })
                .catch(err => {
                if (!(err instanceof errors_1.NotAuthorized)
                    || currUser.id !== userId
                    || !body.password) {
                    return reject(err);
                }
                this._provider.fetchUser(userId)
                    .then(user => {
                    user.password = body.password;
                    return user.save();
                });
            })
                .then(resolve)
                .catch(reject);
        });
    }
    get routing() {
        return new routingInfo_1.RoutingInfo('/users', [
            new route_1.Route('/', this.list, 'GET', true),
            new route_1.Route('/', this.create, 'POST', true),
            new route_1.Route('/:user', this.view, 'GET', true),
            new route_1.Route('/:user', this.update, 'PATCH', true)
        ]);
    }
}
exports.UserController = UserController;
//# sourceMappingURL=user.controller.js.map