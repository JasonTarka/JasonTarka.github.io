'use strict';
class Route {
    constructor(route, handler, method, authenticated) {
        this.route = route.startsWith('/') ? route : '/' + route;
        this.handler = handler;
        this.method = method || 'GET';
        this.authenticated = !!authenticated;
    }
}
exports.Route = Route;
//# sourceMappingURL=route.js.map