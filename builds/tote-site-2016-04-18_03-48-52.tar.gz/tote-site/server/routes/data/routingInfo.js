'use strict';
class RoutingInfo {
    constructor(baseRoute, routes) {
        if (!(routes instanceof Array && routes.length)) {
            throw new Error('"routes" cannot be empty');
        }
        this.baseRoute = baseRoute.startsWith('/')
            ? baseRoute
            : '/' + baseRoute;
        this.routes = routes;
    }
}
exports.RoutingInfo = RoutingInfo;
//# sourceMappingURL=routingInfo.js.map