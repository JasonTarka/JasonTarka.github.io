'use strict';
const auth_provider_1 = require("../domain/providers/auth.provider");
const user_provider_1 = require("../domain/providers/user.provider");
const utils_1 = require("../utils/utils");
let passport = require('passport'), JwtStrategy = require('passport-jwt').Strategy;
function createAuthStrategy() {
    let options = {
        secretOrKey: process.env.TOTE_JWT_SECRET
    };
    passport.use(new JwtStrategy(options, (jwt, done) => validateSession(jwt.id, jwt.sessionKey)
        .then(userId => utils_1.getInstance(user_provider_1.UserProvider).fetchUser(userId))
        .then(user => done(null, user))
        .catch(() => done(null, false))));
    return passport.authenticate('jwt', { session: false });
}
exports.createAuthStrategy = createAuthStrategy;
function validateSession(userId, sessionKey) {
    return new Promise((resolve, reject) => {
        let provider = utils_1.getInstance(auth_provider_1.AuthProvider);
        provider.fetchAuthSession(userId, sessionKey)
            .then(authSession => {
            if (!authSession.isValid) {
                return reject();
            }
            authSession.markUsed();
            resolve(userId);
        })
            .catch(reject);
    });
}
//# sourceMappingURL=auth.js.map